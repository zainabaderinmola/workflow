from django.apps import AppConfig


class AifedayoscrumyConfig(AppConfig):
    name = 'aifedayoscrumy'
